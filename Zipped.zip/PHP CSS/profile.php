<?php
error_reporting(E_ALL ^ E_NOTICE)
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title> Profile Page </title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
	<link rel="stylesheet" href="profile.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
	<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
</head>
<body>
<?php include 'header.php';

?>

	
	<div class="container text-center">
	<h1>Welcome to your Profile Page</h1>
	</div>
	

	<body>
		<?php 
		if(isset($_SESSION["studentid"])){
			echo "<p>Hello " . $_SESSION["stufirst"]. " ". $_SESSION ["stulast"] . "</p>";
			echo "<p> The Current information we have on file for you is as follows: </p>";
			echo "<p> Your assigned student ID# is " . $_SESSION["studentid"] . "</p>";
			echo "<p> Your email address is " . $_SESSION["stuemail"] . "</p>";
			echo "<p> Your current address is " . $_SESSION["stuaddress"] . "</p>";
			echo "<p> Your current phone number is " . $_SESSION["stuphone"] . "</p>";
			echo "<p> Your current declared Major program is " . $_SESSION["stumajor"] . "</p>";
						
		}
		?>
		
		<div class="container text-center">
		<a href="logout.php">Logout</a>
		</div>
		
		
		
		
		<br>



	
<?php include 'footer.php';?>

</body>
</html>

