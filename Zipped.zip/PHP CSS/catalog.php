<?php
error_reporting(E_ALL ^ E_NOTICE)
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">

</head>
<body>
<?php 

include_once 'header.php';
include 'dbh.inc.php';
include_once 'functions.inc.php';

session_start();

$catalog = "SELECT * FROM courses;";
$catalogResults = mysqli_query($conn, $catalog);


?>
	
	<div class="container text-center">
	<h1>Course Catalog:</h1>
	</div>
	
	<body class="bg-dark">
		<div class="container">
			<div class="row mt-5">
				<div class="column">
					<div class="card mt-5">
						<div class="card-header">
							<h2 class="dispaly-6 text-center">Course Catalog Listing</h2>
							
						</div>
						<div class="card-body">
						
							<table class="table table-bordered text-center">
								<tr class="bg-dark text-white">
									<th> Course ID </th>
									<th> Course Name </th>
									<th> Semester </th>
									<th> Available Time </th>
									<th> Enroll </th>
																		
								</tr>
								<tr data-href=>
								<?php
									$resultCheck = mysqli_num_rows($catalogResults);
									if($resultCheck>0){
										while ($row=mysqli_fetch_assoc($catalogResults)){
											echo
											"
											<tr>
												<td>".$row['courseID']."</td>
												<td>".$row['courseName']."</td>
												<td>".$row['courseSem']."</td>
												<td>".$row['courseTime']."</td>
												<td> 
												<a href='enroll.inc.php?courseID=".$row['courseID'] ."' class='btn btn-primary'>Enroll</a>							
																																		
												</td>								
																					
											</tr>
											
											"
											;
										}
									}										
																
								?>
		
							</table>
										
																
							<div class="container text-center">
							<a href="logout.php">Logout</a>
							</div>
							
							<br>
							
											
					<?php include 'footer.php';?>
				</div>
			</div>
		</div>
	</div>
</div>
</body>
</html>

