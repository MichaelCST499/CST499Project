<?php

	if(mysqli_connect_errno ())
	{
			echo mysqli_connect_error();
			exit();
	}
	
	function executeSelectQuery(){
		$host = "localhost";
		$dbusername = "root";
		$dbpassword = "";
		$dbdatabase = "cst499project";	
		$conn = mysqli_connect($host, $dbusername, $dbpassword, $dbdatabase);
		$sql = "SELECT * FROM students";
		$result = mysqli_query($conn, $sql) or die("Bad Query");
		$stmt = $conn-> query($sql);
		
	
	function executeQuery($email, $pass, $first, $last, $address, $phone, $major, $ssn){
		$host = "localhost";
		$dbusername = "root";
		$dbpassword = "";
		$dbdatabase = "cst499project";	
		$conn = mysqli_connect($host, $dbusername, $dbpassword, $dbdatabase);
		$sql = "SELECT * FROM students";
		$result = mysqli_query($conn, $sql) or die("Bad Query");
		$sql  = "INSERT INTO students(email, password, firstName, lastName, address, phone, major, ssn) VALUES (?,?,?,?,?,?,?,?)";
		$stmt = $conn-> prepare($sql);
		$stmt ->execute([$email, $pass, $first, $last, $address, $phone, $major, $ssn]);
		}
	echo executeSelectQuery();
	
?> 
			