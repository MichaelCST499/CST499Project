<?php
		$host = "localhost";
		$dbusername = "root";
		$dbpassword = "";
		$dbdatabase = "cst499project";
		
		$conn = mysqli_connect($host, $dbusername, $dbpassword, $dbdatabase);
		
		if(!$conn){
			die("Connection Failed: " . mysqli_connect_error());
		}
		