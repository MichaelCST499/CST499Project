<?php

include_once 'header.php';
include 'dbh.inc.php';
//include 'functions.inc.php';
include 'catalog.php';




if (isset($_GET['encourseID'])){
	$StuSessID = $_SESSION['studentid'];
	$courseidDis = $_GET['encourseID'];
	//$coursenameDis = $_POST['encourseName'];
	//$coursesemDis = $_POST['encourseSem'];
	//$coursetimeDis = $_POST['encourseTime'];
	
	$disenroll = "DELETE FROM enrollments WHERE studentId = '$StuSessID' AND encourseID = '$courseidDis';";
	mysqli_query($conn, $disenroll);
	//header("Location: courses.php");
	exit();
	
}

