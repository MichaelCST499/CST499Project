<?php
error_reporting(E_ALL ^ E_NOTICE)

?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">

</head>
<body>
<?php

session_start();

include_once 'header.php';
include 'dbh.inc.php';
include 'functions.inc.php';

if(isset($_SESSION['studentid'])){	
	//$id=$_POST['courseID'];
	//$delete =mysqli_query($conn, "DELETE FROM 'enrollments' WHERE 'courseID' = '$id'"); 
$StuSessID = $_SESSION['studentid'];		
$enrolledCourses = "SELECT * FROM enrollments WHERE studentId = '$StuSessID';";
$enrolledResults = mysqli_query($conn, $enrolledCourses);
}


?>

	
	<div class="container text-center">
	<h1>Current Courses:</h1>
	</div>
	
	<body class="bg-dark">
		<div class="container">
			<div class="row mt-5">
				<div class="column">
					<div class="card mt-5">
						<div class="card-header">
							<h2 class="dispaly-6 text-center">Your Current Enrolled Courses</h2>
						</div>
						<div class="card-body">
							<table class="table table-bordered text-center">
								<tr class="bg-dark text-white">
									<td> Course ID </td>
									<td> Course Name </td>
									<td> Semester </td>
									<td> Course Time </td>
									<td> Disenroll </td>
									
								</tr>
								
								<?php
									$resultCheck = mysqli_num_rows($enrolledResults);
									if($resultCheck > 0){
										while ($row=mysqli_fetch_assoc($enrolledResults)){
											echo "
											<tr>
												<td>".$row['encourseID']."</td>
												<td>".$row['encourseName']."</td>
												<td>".$row['encourseSem']."</td>
												<td>".$row['encourseTime']."</td>
												<td>
													<a href='disenroll.inc.php?encourseID=".$row['encourseID']."'  class='btn btn-danger'>Disenroll</a>
												</td>
											</tr>
											";
										}
									}										
																
								?>								
								</table>	
																							
							<div class="container text-center">
							<a href="logout.php">Logout</a>
							</div>
							
							<br>
							
							



						
					<?php include 'footer.php';?>
				</div>
			</div>
		</div>
	</div>
</div>
</body>
</html>

