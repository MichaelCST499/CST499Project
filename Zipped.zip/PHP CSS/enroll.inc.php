<?php
include_once 'header.php';
include 'dbh.inc.php';
//include 'functions.inc.php';
include 'catalog.php';
session_start();

//$StuSessID = $_SESSION['studentid'];
//$cID = $_GET['courseID'];
//$cName = $_GET['courseName'];
//$cSem = $_GET['courseSem'];
//$cTime = $_GET['courseTime'];

//$cID = $result['courseID'];
//$cName = $result['courseName'];
//$cSem = $result['courseSem'];
//$cTime = $result['courseTime'];

if(isset($_GET['courseID'])){
	//echo $_GET['courseID'];	
	//echo $_GET['courseName'];
	//echo $_GET['courseSem'];
	//echo $_GET['courseTime'];
	$StuSessID = $_SESSION['studentid'];					
	//$_SESSION["courseID"] = $cID;
	//$_SESSION["courseName"] = $cName;
	//$_SESSION["courseSem"] = $cSem;
	//$_SESSION["courseTime"] = $cTime;			
	//$cID = $result['courseID'];
	//$cName = $result['courseName'];
	//$cSem = $result['courseSem'];
	//cTime = $result['courseTime'];
	$cID = $_GET['courseID'];
	//$cName = $_GET['courseName'];
	//$cSem = $_GET['courseSem'];
	//$cTime = $_GET['courseTime'];
		if ($cID === '1'){
			$add ="INSERT INTO enrollments (encourseID, studentId, encourseName, encourseSem, encourseTime) VALUES (1, '$StuSessID', 'Computer Science Capstone', 'Winter', '9:00am')";
			mysqli_query($conn, $add);	
			echo("You have been enrolled");
		}
			
		elseif ($cID === '2'){
			$add2 ="INSERT INTO enrollments (encourseID, studentId, encourseName, encourseSem, encourseTime) VALUES (2, '$StuSessID', 'Computer Science Capstone', 'Spring', '10:00am')";
			mysqli_query($conn, $add2);	
			echo("You have been enrolled");	
		}			
			
		elseif ($cID === '3'){
				$add3 ="INSERT INTO enrollments (encourseID, studentId, encourseName, encourseSem, encourseTime) VALUES (3, '$StuSessID', 'Math', 'Winter', '11:00am')";
				mysqli_query($conn, $add3);	
				echo("You have been enrolled.");
		}
			
		elseif ($cID === '4'){
			$add4 ="INSERT INTO enrollments (encourseID, studentId, encourseName, encourseSem, encourseTime) VALUES (4, '$StuSessID', 'Math', 'Spring', '12:00pm')";
			mysqli_query($conn, $add4);	
			echo("You have been enrolled.");
		}
		
		elseif ($cID === '5'){
			$add5 ="INSERT INTO enrollments (encourseID, studentId, encourseName, encourseSem, encourseTime) VALUES (5, '$StuSessID', 'English', 'Winter', '3:00pm')";
			mysqli_query($conn, $add5);	
			echo("You have been enrolled.");
		}	
		
		elseif ($cID === '6'){
			$add6 ="INSERT INTO enrollments (encourseID, studentId, encourseName, encourseSem, encourseTime) VALUES (6, '$StuSessID', 'English', 'Spring', '4:00pm')";
			mysqli_query($conn, $add6);	
			echo("You have been enrolled.");
		}
				
		elseif ($cID === '7'){
			$add7 ="INSERT INTO enrollments (encourseID, studentId, encourseName, encourseSem, encourseTime) VALUES (7, '$StuSessID', 'Archaeology', 'Winter', '1:00pm')";
			mysqli_query($conn, $add7);	
			echo("You have been enrolled.");
		}
				
		elseif ($cID === '8'){
			$add8 ="INSERT INTO enrollments (encourseID, studentId, encourseName, encourseSem, encourseTime) VALUES (8, '$StuSessID', 'Archaeology', 'Spring', '2:00pm')";
			mysqli_query($conn, $add8);	
			echo("You have been enrolled.");
		}
}	

