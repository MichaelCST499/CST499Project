<?php
	
	error_reporting(E_ALL ^ E_NOTICE);
	
?>


<body>

<?php require 'header.php';?>

	<div class="container text-center">
	<h1>Welcome to the Home page</h1>
	<h3>Please choose "Login" if you are a returning student</h3>
	<h3>If you are a first time visitor, please register</h3>
	</div>
	
<?php require_once 'footer.php';?>

	<?php
	require 'functions.inc.php'; ?>
	

<br>

</body>
</html>
