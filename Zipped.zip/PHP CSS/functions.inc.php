<?php

function emptyInputSignup($email, $pass, $pass2, $first, $last, $address, $phone, $major, $ssn){
		$result;
		if (empty($email) || empty($pass) || empty($pass2) || empty($first) || empty($last) || empty($address) || empty($phone) || empty($major) || empty($ssn)){
			$result = true;
		}
		else{
			$result = false;
		}
		return $result; 
}
	
function invalidEmail($email){
		$result;
		if (!filter_var($email, FILTER_VALIDATE_EMAIL)){
			$result = true;
		}
		else{
			$result = false;
		}
		return $result; 
}
	
function invalidPass($pass, $pass2){
		$result;
		if ($pass !== $pass2){
			$result = true;
		}
		else{
			$result = false;
		}
		return $result; 
}
	
function uidExists($conn, $email){
	$sql = "SELECT * FROM students WHERE stuEmail = ?;";
	$stmt = mysqli_stmt_init($conn);
	if(!mysqli_stmt_prepare($stmt, $sql)){
		header("location: registration.php?error=stmtfailed");
		exit();
		
	}
	
	mysqli_stmt_bind_param($stmt, "s", $email);
	mysqli_stmt_execute($stmt);
	
	$resultData = mysqli_stmt_get_result($stmt);
		
	if($row = mysqli_fetch_assoc($resultData)){
		return $row;
	
	}
	else{
		$result = false;
		return $result;
	}
	
	mysqli_stmt_close($stmt);
}

function createUser($conn, $email, $pass, $first, $last, $address, $phone, $major, $ssn){
	$sql = "INSERT INTO students(stuEmail, stuPass, stuFirst, stuLast, stuAddress, stuPhone, stuMajor, stuSSN) VALUES (?,?,?,?,?,?,?,?);";	
	$stmt = mysqli_stmt_init($conn);
	if(!mysqli_stmt_prepare($stmt, $sql)){
		header("location: registration.php?error=stmtfailed");
		exit();
	}
	
	$hashedPwd = password_hash($pass, PASSWORD_DEFAULT);
	
	mysqli_stmt_bind_param($stmt, "ssssssss", $email, $hashedPwd, $first, $last, $address, $phone, $major, $ssn);
	mysqli_stmt_execute($stmt);
	mysqli_stmt_close($stmt);
	header("location: login.php?error=none");
	exit();
	
}

function emptyInputLogin($username, $pwd){
		$result;
		if (empty($username) || empty($pwd)){
			$result = true;
		}
		else{
			$result = false;
		}
		return $result; 
}

function loginUser($conn, $username, $pwd){
	$uidExists = uidExists($conn, $username);
	
	if ($uidExists === false){
		header("location: login.php?error=uidwronglogin");
		exit();
}

	$pwdHashed =$uidExists["stuPass"];
	$checkPwd = password_verify($pwd, $pwdHashed);
	
	if($checkPwd === false){
		header("location: login.php?error=chkPasswronglogin");
		exit();
	}
	else if($checkPwd === true){
		session_start();
		$_SESSION["studentid"] = $uidExists["studentId"];
		$_SESSION["stufirst"] = $uidExists["stuFirst"];
		$_SESSION["stulast"] = $uidExists["stuLast"];
		$_SESSION["stuemail"] = $uidExists["stuEmail"];
		$_SESSION["stuaddress"] = $uidExists["stuAddress"];
		$_SESSION["stuphone"] = $uidExists["stuPhone"];
		$_SESSION["stumajor"] = $uidExists["stuMajor"];
				
		
		header("location: profile.php");
		exit();
	}
		
}
?>