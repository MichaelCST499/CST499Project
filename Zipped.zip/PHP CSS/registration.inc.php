<?php

if(isset($_POST["submit"])){
	$email = $_POST["email"];
	$pass = $_POST["password"];
	$pass2 = $_POST["password2"];
	$first = $_POST["first"];
	$last = $_POST["lastname"];
	$address = $_POST["address"];
	$phone = $_POST["phone"];
	$major = $_POST["major"];
	$ssn = $_POST["ssn"];	
	
	require_once 'dbh.inc.php';
	require_once 'functions.inc.php';
	
	if(emptyInputSignup($email, $pass, $pass2, $first, $last, $address, $phone, $major, $ssn) !== false){
		header("location: registration.php?error=emptyinput");
		exit();
	}
	
	if(invalidEmail($email) !== false){
		header("location: registration.php?error=invalidemail");
		exit();
	}
	
	if(invalidPass($pass, $pass2) !== false){
		header("location: registration.php?error=invalidpass");
		exit();
	}
	
	if(uidExists($conn, $email) !== false){
		header("location: registration.php?error=userexists");
		exit();
	}
	
	createUser($conn, $email, $pass, $first, $last, $address, $phone, $major, $ssn);	
}
	else{
	header("location: registration.php");
	exit();
	}

?>