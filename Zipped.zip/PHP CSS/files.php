<html>
<head>
	<meta charset="UTF-8">
	<title>Document</title>
</head>
<body>

<form action="files.php" method="post" enctype="multipart/form-data">
Please select "Choose File" to pick the file you wish to upload, then hit "Submit"<br>
	<input type="file" name="file">
	<button type="submit" name="submit">SUBMIT</button>
</form>

<?php
//$_FILES Superglobal
$conn = mysqli_connect("localhost","root","","cst499project");

if(isset($_POST['submit'])){
	$conn = mysqli_connect("localhost","root","","cst499project");
	if($conn){
		echo "<br> Connected";
	}
}	
	$filename = $_FILES['file']['name'];
	$tempname = $_FILES['file']['tmp_name'];
	
	echo $filename;
	echo $tempname;
	
	$folder ='uploads/';
	
	move_uploaded_file($tempname,$folder.$filename);
	
	$sql ="INSERT INTO `files` (`id`, `files`) VALUES (NULL, '$filename')";
	
	$query = mysqli_query($conn,$sql);
	if (empty ($filename)){
		echo "<br> Please choose a file and try again.";
	}
	
echo $name = $_FILES['file']['name']."<br>";
echo $type = $_FILES['file']['type']."<br>";

?>

</body>
</html>