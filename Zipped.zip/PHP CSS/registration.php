<?php
error_reporting(E_ALL ^ E_NOTICE)
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title> Registration Page </title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
	<script src="http://maxcdn.boostrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
</head>
<body>
<?php include_once 'header.php';?>

	<div class="container text-center">
	<h1>Welcome to the Registration Page</h1>
	</div>
	
		<?php
	
	if(isset($_GET["error"])){
		if($_GET["error"] == "userexists"){
			echo "<p> This user already exists<p>";
		}
		else if($_GET["error"] == "emptyinput"){
			echo "<p> Please complete all fields<p>";
		}
		else if($_GET["error"] == "invalidemail"){
			echo "<p> Please enter a correctly formatted email likethis@example.com<p>";
		}
		else if($_GET["error"] == "invalidpass"){
			echo "<p> Your entered passwords did not match, please try again.<p>";
		}
		else if($_GET["error"] == "none"){
			echo "<p> You registered succesfully.<p>";
		}
		

	}
	?>
		<div class="container text-center">
		<h2>Sign Up</h2>
		<form action="registration.inc.php"	method="post">

	         Please enter your Email Address: <input type="email" name="email" placeholder= " Email "/><br>
	              Please enter your Password: <input type="password" name="password" placeholder= " Password "/><br>
				  Please re-enter your Password: <input type="password" name="password2" placeholder= " Confirm Password "/><br>
	            Please enter your First Name: <input type="text" name="first" placeholder= " Frist Name "/><br>
	             Please enter your Last Name: <input type="text" name="lastname" placeholder= " Last Name "/><br>
	               Please enter your Address: <input type="text" name="address" placeholder= " Address "/><br>
	          Please enter your Phone Number: <input type="text" name="phone" placeholder= " Phone Number "/><br>
	                Please enter your Current Major: <input type="text" name="major" placeholder= " Major Program Field "/><br>
	Please enter your Social Security Number: <input type="password" name="ssn" placeholder= " SSN "/><br>
			<button type="submit" name="submit" >Register</button> 
		</form>
	</div>
</section>
<br>

<?php include_once 'footer.php';?>

</body>
</html>