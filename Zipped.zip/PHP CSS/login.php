<?php include_once 'header.php';?>

	<div class="container text-center">
	<h1>Welcome</h1>
	</div>
		<div class="container text-center">
		<h3>Please Login</h3>
		<form action="login.inc.php" method="post">

	         Please enter your Email Address: <input type="email" name="email" placeholder= " Email "/><br>
	              Please enter your Password: <input type="password" name="password" placeholder= " Password "/><br>
				
			<button type="submit" name="submit" >Login</button> 
		</form>
	</div>
</section>
<br>
	<?php
	
	if(isset($_GET["error"])){
		if($_GET["error"] == "stmtfailed"){
			echo "<p> This user already exists<p>";
		}
		else if($_GET["error"] == "emptyinput"){
			echo "<p> Please complete all fields<p>";
		}
		else if($_GET["error"] == "invalidemail"){
			echo "<p> Please enter a correctly formatted email likethis@example.com<p>";
		}
		else if($_GET["error"] == "invalidpass"){
			echo "<p> Your entered passwords did not match, please try again.<p>";
		}
		else if($_GET["error"] == "wronglogin"){
			echo "<p> Your entered an incorrect email and/or password, please try again.<p>";
		}
		else if($_GET["error"] == "none"){
			echo "<p> You registered succesfully.<p>";
		}
		

	}
	?>

<?php include_once 'footer.php';?>